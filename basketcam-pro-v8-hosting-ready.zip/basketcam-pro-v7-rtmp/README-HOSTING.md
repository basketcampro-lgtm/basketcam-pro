# BasketCam Pro V8 Hosting Ready

## 1) Subir PWA a Vercel

1. Crea un repo en GitHub y sube este proyecto.
2. Entra a Vercel.
3. New Project → importa el repo.
4. Framework: Vite.
5. Environment Variable:
   - `VITE_RTMP_SERVER_URL`
   - valor temporal: déjalo vacío hasta tener Cloud Run.
6. Deploy.

Cuando Cloud Run esté listo, vuelves a Vercel → Settings → Environment Variables:
`VITE_RTMP_SERVER_URL=https://TU-SERVIDOR-RTMP.run.app`

Redeploy.

## 2) Subir servidor RTMP a Google Cloud Run

Requisitos:
- Google Cloud SDK instalado
- proyecto activo en Google Cloud
- billing habilitado

Comandos:

```bash
gcloud auth login
gcloud config set project TU_PROJECT_ID
gcloud services enable run.googleapis.com cloudbuild.googleapis.com artifactregistry.googleapis.com
gcloud builds submit --config cloudbuild.yaml
```

Cuando termine, copia la URL que Cloud Run te dará.

## 3) Conectar Vercel con Cloud Run

En Vercel agrega:

```bash
VITE_RTMP_SERVER_URL=https://TU-SERVIDOR-RTMP.run.app
```

Luego redeploy.

## 4) Probar en celular

Abre la URL de Vercel en el celular. Al ser HTTPS, la cámara debe funcionar.

## 5) YouTube

En YouTube Studio crea el directo, copia la URL RTMP completa:

```text
rtmp://a.rtmp.youtube.com/live2/TU-STREAM-KEY
```

La pegas en BasketCam y presionas Transmitir.
