import express from "express";
import cors from "cors";
import http from "http";
import { Server } from "socket.io";
import { spawn } from "child_process";
import dotenv from "dotenv";

dotenv.config();

const app = express();
app.use(cors());
app.use(express.json());

const httpServer = http.createServer(app);

const io = new Server(httpServer, {
  cors: {
    origin: process.env.ALLOWED_ORIGIN || "*",
    methods: ["GET", "POST"],
  },
  maxHttpBufferSize: 1e8,
});

const activeStreams = new Map();

app.get("/", (req, res) => {
  res.json({
    ok: true,
    app: "BasketCam Pro RTMP Server",
    status: "running",
  });
});

io.on("connection", (socket) => {
  console.log("Cliente conectado:", socket.id);

  socket.on("start-stream", ({ rtmpUrl }) => {
    if (!rtmpUrl || !rtmpUrl.startsWith("rtmp")) {
      socket.emit("stream-error", "URL RTMP inválida.");
      return;
    }

    console.log("Iniciando stream hacia:", rtmpUrl.replace(/live2\/.*/, "live2/*****"));

    const ffmpegArgs = [
      "-re",
      "-f", "webm",
      "-i", "pipe:0",
      "-map", "0:v:0",
      "-map", "0:a?",
      "-c:v", "libx264",
      "-preset", "veryfast",
      "-tune", "zerolatency",
      "-pix_fmt", "yuv420p",
      "-r", "30",
      "-g", "60",
      "-b:v", "2500k",
      "-maxrate", "2500k",
      "-bufsize", "5000k",
      "-c:a", "aac",
      "-b:a", "128k",
      "-ar", "44100",
      "-f", "flv",
      rtmpUrl,
    ];

    const ffmpeg = spawn("ffmpeg", ffmpegArgs, {
      stdio: ["pipe", "pipe", "pipe"],
    });

    activeStreams.set(socket.id, ffmpeg);

    ffmpeg.stderr.on("data", (data) => {
      const msg = data.toString();
      console.log("[ffmpeg]", msg);
      if (msg.toLowerCase().includes("error")) {
        socket.emit("stream-error", msg.slice(0, 300));
      }
    });

    ffmpeg.on("error", (err) => {
      console.error("FFmpeg error:", err.message);
      socket.emit("stream-error", "FFmpeg no está instalado o no está en PATH.");
    });

    ffmpeg.on("close", (code) => {
      console.log("FFmpeg cerrado:", code);
      activeStreams.delete(socket.id);
    });

    socket.emit("stream-started");
  });

  socket.on("video-chunk", (chunk) => {
    const ffmpeg = activeStreams.get(socket.id);
    if (!ffmpeg || !ffmpeg.stdin.writable) return;

    try {
      ffmpeg.stdin.write(Buffer.from(chunk));
    } catch (err) {
      socket.emit("stream-error", "No se pudo enviar chunk a FFmpeg.");
    }
  });

  socket.on("stop-stream", () => {
    stopStream(socket.id);
  });

  socket.on("disconnect", () => {
    console.log("Cliente desconectado:", socket.id);
    stopStream(socket.id);
  });
});

function stopStream(socketId) {
  const ffmpeg = activeStreams.get(socketId);
  if (!ffmpeg) return;

  try {
    ffmpeg.stdin.end();
    ffmpeg.kill("SIGINT");
  } catch {}

  activeStreams.delete(socketId);
}

const PORT = process.env.PORT || 4000;
httpServer.listen(PORT, () => {
  console.log(`BasketCam RTMP server listo en http://localhost:${PORT}`);
});
