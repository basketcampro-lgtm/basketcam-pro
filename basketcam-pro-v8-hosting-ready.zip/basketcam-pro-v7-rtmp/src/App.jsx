import React, { useEffect, useRef, useState } from "react";
import "./index.css";
import { io } from "socket.io-client";

const COURT_DEMO =
  "https://images.unsplash.com/photo-1546519638-68e109498ffc?auto=format&fit=crop&w=1600&q=80";

const PERIODS = ["1ST", "2ND", "3RD", "4TH", "OT"];
const PERIOD_START_TIME = "10:00";

const initialTeams = {
  home: { name: "BULLS", color: "#ff2e3d", score: 34, fouls: 3, logo: null },
  away: { name: "WOLVES", color: "#1682ff", score: 38, fouls: 2, logo: null },
};

function fileToUrl(file, cb) {
  if (!file) return;
  const reader = new FileReader();
  reader.onload = () => cb(reader.result);
  reader.readAsDataURL(file);
}

function UploadButton({ label, accept = "image/*", onLoad }) {
  return (
    <label className="uploadBtn">
      <span>⬆</span> {label}
      <input type="file" accept={accept} onChange={(e) => fileToUrl(e.target.files?.[0], onLoad)} />
    </label>
  );
}

function TeamLogo({ team }) {
  return <div className="teamLogo">{team.logo ? <img src={team.logo} alt="" /> : <span>🏀</span>}</div>;
}

function SponsorLogo({ src, fallback }) {
  return <div className="sponsorLogo">{src ? <img src={src} alt="" /> : <strong>{fallback}</strong>}</div>;
}

function FullscreenAd({ ad, visible, onClose }) {
  const videoRef = useRef(null);

  if (!visible || !ad?.src) return null;

  return (
    <div className="fullscreenAd">
      <button className="closeAd" onClick={onClose}>× Cerrar anuncio</button>

      {ad.type === "video" ? (
        <video
          ref={videoRef}
          src={ad.src}
          autoPlay
          playsInline
          controls={false}
          onEnded={onClose}
          onLoadedMetadata={() => {
            if (videoRef.current && videoRef.current.duration > 30.5) {
              alert("El video del anuncio no debe pasar de 30 segundos.");
              onClose();
            }
          }}
        />
      ) : (
        <img src={ad.src} alt="Anuncio" />
      )}

      <div className="adBadge">PUBLICIDAD · BasketCam PRO</div>
    </div>
  );
}

function ScoreOverlay({ teams, period, clock, shotClock, live, sponsors, bannerOn, cameraOn, possession }) {
  return (
    <div className="overlay">
      <div className="overlayTop">
        <SponsorLogo src={sponsors.left} fallback="QUICK ENERGY" />
        <SponsorLogo src={sponsors.right} fallback="SAN CARLOS CLUB" />
      </div>

      {!cameraOn && <div className="demoTag">MODO DEMO · ABRE LA CÁMARA</div>}

      <div className="overlayBottom">
        {live && <div className="livePill">● LIVE</div>}

        <div className="scorebar smallScorebar">
          <div className={`scoreSide homeSide ${possession === "home" ? "hasBall" : ""}`} style={{ "--team": teams.home.color }}>
            <TeamLogo team={teams.home} />
            <div className="teamText">
              <b>{teams.home.name}</b>
              <small>FOULS {"●".repeat(Math.min(teams.home.fouls, 5))} {teams.home.fouls}</small>
            </div>
            <strong className="scoreNum">{teams.home.score}</strong>
          </div>

          <div className="scoreMiddle">
            <b>{period}</b>
            <strong>{clock}</strong>
            <span>{shotClock}</span>
          </div>

          <div className={`scoreSide awaySide ${possession === "away" ? "hasBall" : ""}`} style={{ "--team": teams.away.color }}>
            <strong className="scoreNum">{teams.away.score}</strong>
            <div className="teamText right">
              <b>{teams.away.name}</b>
              <small>FOULS {"●".repeat(Math.min(teams.away.fouls, 5))} {teams.away.fouls}</small>
            </div>
            <TeamLogo team={teams.away} />
          </div>
        </div>

        {bannerOn && (
          <div className="adBanner">
            {sponsors.banner ? (
              <img src={sponsors.banner} alt="" />
            ) : (
              <>
                <div className="adIcon">💧</div>
                <div className="adCopy"><b>HIDRÁTATE</b><span>JUEGA AL MÁXIMO</span></div>
                <em>POWER PLUS</em>
                <button>CONOCE MÁS</button>
              </>
            )}
          </div>
        )}
      </div>
    </div>
  );
}

function TeamPanel({ side, team, score }) {
  return (
    <div className={`teamPanel ${side === "home" ? "red" : "blue"}`}>
      <div className="teamPanelTitle">{team.name}</div>
      <div className="teamPanelScore">{team.score}</div>
      <div className="pointGrid">
        <button onClick={() => score(side, 1)}>+1</button>
        <button onClick={() => score(side, 2)}>+2</button>
        <button onClick={() => score(side, 3)}>+3</button>
      </div>
      <button className="minusWide" onClick={() => score(side, -1)}>-1</button>
    </div>
  );
}

function FoulBox({ side, team, update }) {
  return (
    <div className="foulBox">
      <label>FALTAS</label>
      <div>
        <button onClick={() => update(side, { fouls: Math.max(0, team.fouls - 1) })}>−</button>
        <strong>{team.fouls}</strong>
        <button className="yellowText" onClick={() => update(side, { fouls: team.fouls + 1 })}>+</button>
      </div>
    </div>
  );
}

export default function App() {
  const stageRef = useRef(null);
  const videoRef = useRef(null);
  const recorderRef = useRef(null);
  const chunksRef = useRef([]);
  const rtmpRecorderRef = useRef(null);
  const socketRef = useRef(null);

  const [teams, setTeams] = useState(initialTeams);
  const [period, setPeriod] = useState("1ST");
  const [clock, setClock] = useState(PERIOD_START_TIME);
  const [shotClock, setShotClock] = useState(24);
  const [shotRunning, setShotRunning] = useState(false);
  const [clockRunning, setClockRunning] = useState(false);
  const [live, setLive] = useState(false);
  const [cameraOn, setCameraOn] = useState(false);
  const [bannerOn, setBannerOn] = useState(true);
  const [soundOn, setSoundOn] = useState(true);
  const [possession, setPossession] = useState("home");
  const [sponsors, setSponsors] = useState({ left: null, right: null, banner: null });
  const [fullAd, setFullAd] = useState(null);
  const [showFullAd, setShowFullAd] = useState(false);
  const [recording, setRecording] = useState(false);
  const [rtmpUrl, setRtmpUrl] = useState("");
  const [rtmpLive, setRtmpLive] = useState(false);
  const [rtmpStatus, setRtmpStatus] = useState("Servidor RTMP listo");

  useEffect(() => {
    const svg = `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 128 128">
      <rect width="128" height="128" rx="28" fill="#05070b"/>
      <circle cx="64" cy="64" r="42" fill="#ffbf00"/>
      <path d="M24 64h80M64 22v84M36 36c20 17 36 17 56 0M36 92c20-17 36-17 56 0" stroke="#05070b" stroke-width="7" fill="none" stroke-linecap="round"/>
      <path d="M96 22l14 14-14 14" stroke="#ff2e3d" stroke-width="8" fill="none" stroke-linecap="round" stroke-linejoin="round"/>
    </svg>`;
    const href = "data:image/svg+xml," + encodeURIComponent(svg);
    let link = document.querySelector("link[rel='icon']");
    if (!link) {
      link = document.createElement("link");
      link.rel = "icon";
      document.head.appendChild(link);
    }
    link.href = href;
    document.title = "BasketCam Pro";
  }, []);

  useEffect(() => {
    const saved = localStorage.getItem("basketcam-v6-state");
    if (!saved) return;
    try {
      const data = JSON.parse(saved);
      if (data.teams) setTeams(data.teams);
      if (data.sponsors) setSponsors(data.sponsors);
      if (data.period) setPeriod(data.period);
      if (data.clock) setClock(data.clock);
      if (data.bannerOn !== undefined) setBannerOn(data.bannerOn);
    } catch {}
  }, []);

  useEffect(() => {
    const data = { teams, sponsors, period, clock, bannerOn };
    localStorage.setItem("basketcam-v6-state", JSON.stringify(data));
  }, [teams, sponsors, period, clock, bannerOn]);

  useEffect(() => {
    if (!shotRunning) return;
    const id = setInterval(() => setShotClock((v) => (v <= 0 ? 24 : v - 1)), 1000);
    return () => clearInterval(id);
  }, [shotRunning]);

  useEffect(() => {
    if (!clockRunning) return;
    const id = setInterval(() => {
      setClock((current) => {
        const [m, s] = current.split(":").map(Number);
        const total = Math.max(0, (m || 0) * 60 + (s || 0) - 1);
        return `${String(Math.floor(total / 60)).padStart(2, "0")}:${String(total % 60).padStart(2, "0")}`;
      });
    }, 1000);
    return () => clearInterval(id);
  }, [clockRunning]);

  useEffect(() => {
    if (!showFullAd || !fullAd || fullAd.type !== "image") return;
    const id = setTimeout(() => setShowFullAd(false), 30000);
    return () => clearTimeout(id);
  }, [showFullAd, fullAd]);

  async function startCamera() {
    try {
      const stream = await navigator.mediaDevices.getUserMedia({ video: { facingMode: "environment" }, audio: true });
      videoRef.current.srcObject = stream;
      setCameraOn(true);
    } catch {
      alert("No se pudo abrir la cámara. Revisa permisos.");
    }
  }

  function fullScreen() {
    if (!stageRef.current) return;
    if (document.fullscreenElement) document.exitFullscreen();
    else stageRef.current.requestFullscreen?.();
  }

  async function startRecording() {
    try {
      const stream = await navigator.mediaDevices.getDisplayMedia({
        video: { frameRate: 30 },
        audio: true,
      });

      chunksRef.current = [];
      const recorder = new MediaRecorder(stream, { mimeType: "video/webm" });

      recorder.ondataavailable = (event) => {
        if (event.data && event.data.size > 0) chunksRef.current.push(event.data);
      };

      recorder.onstop = () => {
        const blob = new Blob(chunksRef.current, { type: "video/webm" });
        const url = URL.createObjectURL(blob);
        const a = document.createElement("a");
        a.href = url;
        a.download = `basketcam-pro-${Date.now()}.webm`;
        a.click();
        URL.revokeObjectURL(url);
        setRecording(false);
      };

      stream.getVideoTracks()[0].onended = () => {
        if (recorder.state !== "inactive") recorder.stop();
      };

      recorderRef.current = recorder;
      recorder.start();
      setRecording(true);
    } catch {
      alert("No se pudo iniciar la grabación. Elige la pestaña de BasketCam cuando el navegador lo pida.");
    }
  }

  function stopRecording() {
    if (recorderRef.current && recorderRef.current.state !== "inactive") {
      recorderRef.current.stop();
    }
  }

  async function startRtmpLive() {
    if (!rtmpUrl.trim()) {
      alert("Pega primero la URL RTMP completa de YouTube.");
      return;
    }

    try {
      setRtmpStatus("Selecciona la pestaña de BasketCam para transmitir...");
      const captureStream = await navigator.mediaDevices.getDisplayMedia({
        video: { frameRate: 30 },
        audio: true,
      });

      const socket = io(import.meta.env.VITE_RTMP_SERVER_URL || "http://localhost:4000", {
        transports: ["websocket"],
      });

      socketRef.current = socket;

      socket.on("connect", () => {
        setRtmpStatus("Conectado al servidor. Iniciando FFmpeg...");
        socket.emit("start-stream", { rtmpUrl: rtmpUrl.trim() });
      });

      socket.on("stream-started", () => {
        setRtmpStatus("Transmitiendo hacia YouTube RTMP");
        setRtmpLive(true);
        setLive(true);
      });

      socket.on("stream-error", (message) => {
        setRtmpStatus("Error: " + message);
      });

      socket.on("disconnect", () => {
        if (rtmpLive) setRtmpStatus("Servidor desconectado");
      });

      const mimeType = MediaRecorder.isTypeSupported("video/webm;codecs=vp8,opus")
        ? "video/webm;codecs=vp8,opus"
        : "video/webm";

      const recorder = new MediaRecorder(captureStream, {
        mimeType,
        videoBitsPerSecond: 2500000,
        audioBitsPerSecond: 128000,
      });

      recorder.ondataavailable = async (event) => {
        if (event.data && event.data.size > 0 && socket.connected) {
          const buffer = await event.data.arrayBuffer();
          socket.emit("video-chunk", buffer);
        }
      };

      recorder.onstop = () => {
        socket.emit("stop-stream");
        socket.disconnect();
        setRtmpLive(false);
        setLive(false);
        setRtmpStatus("Transmisión detenida");
      };

      captureStream.getVideoTracks()[0].onended = () => {
        if (recorder.state !== "inactive") recorder.stop();
      };

      rtmpRecorderRef.current = recorder;
      recorder.start(1000);
    } catch {
      setRtmpStatus("No se pudo iniciar RTMP. Revisa permisos o servidor.");
    }
  }

  function stopRtmpLive() {
    if (rtmpRecorderRef.current && rtmpRecorderRef.current.state !== "inactive") {
      rtmpRecorderRef.current.stop();
    }
  }

  function update(side, data) {
    setTeams((p) => ({ ...p, [side]: { ...p[side], ...data } }));
  }

  function score(side, points) {
    setTeams((p) => ({ ...p, [side]: { ...p[side], score: Math.max(0, p[side].score + points) } }));
  }

  function addTime(seconds) {
    setClock((current) => {
      const [m, s] = current.split(":").map(Number);
      const total = Math.max(0, (m || 0) * 60 + (s || 0) + seconds);
      return `${String(Math.floor(total / 60)).padStart(2, "0")}:${String(total % 60).padStart(2, "0")}`;
    });
  }

  function changePeriod(direction) {
    const currentIndex = PERIODS.indexOf(period);
    const safeIndex = currentIndex === -1 ? 0 : currentIndex;
    const nextIndex = Math.max(0, Math.min(PERIODS.length - 1, safeIndex + direction));
    setPeriod(PERIODS[nextIndex]);
    setClock(PERIOD_START_TIME);
    setShotClock(24);
    setClockRunning(false);
    setShotRunning(false);
  }

  function loadFullAd(dataUrl) {
    const type = dataUrl.startsWith("data:video") ? "video" : "image";
    setFullAd({ src: dataUrl, type });
  }

  return (
    <main className="app">
      <header className="topbar">
        <div className="brand">BASKETCAM <span>PRO</span></div>
        <div className="topActions">
          <button onClick={fullScreen}>⛶ Pantalla completa</button>
          <button onClick={startCamera}>📷 Abrir cámara</button>
          <button className={recording ? "danger" : ""} onClick={recording ? stopRecording : startRecording}>
            {recording ? "■ Detener grabación" : "● Grabar live"}
          </button>
          <button className={rtmpLive ? "danger" : "goLive"} onClick={rtmpLive ? stopRtmpLive : startRtmpLive}>
            {rtmpLive ? "Detener RTMP" : "Enviar RTMP"}
          </button>
        </div>
      </header>

      <section className="mainGrid">
        <div className="left">
          <div ref={stageRef} className="videoStage">
            <img className={`demoCourt ${cameraOn ? "hide" : ""}`} src={COURT_DEMO} alt="" />
            <video ref={videoRef} autoPlay playsInline muted />
            <ScoreOverlay teams={teams} period={period} clock={clock} shotClock={shotClock} live={live} sponsors={sponsors} bannerOn={bannerOn} cameraOn={cameraOn} possession={possession} />
            <FullscreenAd ad={fullAd} visible={showFullAd} onClose={() => setShowFullAd(false)} />
          </div>

          <div className="sponsorPanel">
            <h3>PATROCINADORES</h3>
            <UploadButton label="Sponsor izquierdo" onLoad={(url) => setSponsors((p) => ({ ...p, left: url }))} />
            <UploadButton label="Sponsor derecho" onLoad={(url) => setSponsors((p) => ({ ...p, right: url }))} />
            <UploadButton label="Banner inferior" onLoad={(url) => setSponsors((p) => ({ ...p, banner: url }))} />
            <button onClick={() => setBannerOn(!bannerOn)}>{bannerOn ? "Ocultar banner" : "Mostrar banner"}</button>
          </div>
        </div>

        <aside className="controlPanel">
          <div className="tabs">
            <button className="active">MARCADOR</button>
            <button>EQUIPOS</button>
            <button>BANNERS</button>
          </div>

          <div className="panelBox">
            <div className="scoreControlGrid">
              <TeamPanel side="home" team={teams.home} score={score} />

              <div className="centerControl">
                <label>PERIODO</label>
                <div className="periodControl">
                  <button onClick={() => changePeriod(-1)}>‹</button>
                  <input value={period} onChange={(e) => setPeriod(e.target.value)} />
                  <button onClick={() => changePeriod(1)}>›</button>
                </div>

                <label>TIEMPO</label>
                <input className="clockInput" value={clock} onChange={(e) => setClock(e.target.value)} />

                <div className="transport">
                  <button onClick={() => setClockRunning(!clockRunning)}>{clockRunning ? "Ⅱ" : "▷"}</button>
                  <button onClick={() => setClock(PERIOD_START_TIME)}>↻</button>
                </div>
              </div>

              <TeamPanel side="away" team={teams.away} score={score} />
            </div>

            <div className="secondRow">
              <FoulBox side="home" team={teams.home} update={update} />

              <div className="possession">
                <label>POSESIÓN</label>
                <div>
                  <button onClick={() => setPossession("home")}>‹</button>
                  <span className={possession === "home" ? "posHome" : "posAway"}></span>
                  <button onClick={() => setPossession("away")}>›</button>
                </div>
              </div>

              <FoulBox side="away" team={teams.away} update={update} />
            </div>

            <div className="shotControl">
              <label>SHOT CLOCK</label>
              <div><strong>{shotClock}</strong><button onClick={() => setShotRunning(!shotRunning)}>{shotRunning ? "Ⅱ" : "▷"}</button><button onClick={() => setShotClock(24)}>↻</button></div>
            </div>

            <div className="timeSound">
              <div className="timePad">
                <label>TIEMPO</label>
                <div>
                  <button onClick={() => addTime(60)}>+1:00</button>
                  <button onClick={() => addTime(30)}>+30</button>
                  <button onClick={() => addTime(10)}>+10</button>
                  <button onClick={() => addTime(5)}>+5</button>
                  <button onClick={() => addTime(-60)}>-1:00</button>
                  <button onClick={() => addTime(-30)}>-30</button>
                  <button onClick={() => addTime(-10)}>-10</button>
                  <button onClick={() => addTime(-5)}>-5</button>
                </div>
              </div>

              <div className="soundBox">
                <label>SONIDO</label>
                <div className="soundLine">
                  <span>🔊</span>
                  <button className={soundOn ? "toggle on" : "toggle"} onClick={() => setSoundOn(!soundOn)}><i /></button>
                </div>
              </div>
            </div>
          </div>

          <div className="rtmpBox">
            <label>YOUTUBE RTMP / STREAM KEY</label>
            <input
              value={rtmpUrl}
              onChange={(e) => setRtmpUrl(e.target.value)}
              placeholder="rtmp://a.rtmp.youtube.com/live2/TU-STREAM-KEY"
            />
            <div className="rtmpActions">
              <button className={rtmpLive ? "stopRecordBtn" : "recordBtn"} onClick={rtmpLive ? stopRtmpLive : startRtmpLive}>
                {rtmpLive ? "Detener transmisión RTMP" : "Transmitir a YouTube"}
              </button>
            </div>
            <small>{rtmpStatus}</small>
          </div>

          <div className="editBox">
            <div>
              <label>NOMBRE / COLOR EQUIPO 1</label>
              <div className="editRow">
                <input value={teams.home.name} onChange={(e) => update("home", { name: e.target.value })} />
                <input type="color" value={teams.home.color} onChange={(e) => update("home", { color: e.target.value })} />
              </div>
              <UploadButton label="Logo equipo 1" onLoad={(url) => update("home", { logo: url })} />
            </div>

            <div>
              <label>NOMBRE / COLOR EQUIPO 2</label>
              <div className="editRow">
                <input value={teams.away.name} onChange={(e) => update("away", { name: e.target.value })} />
                <input type="color" value={teams.away.color} onChange={(e) => update("away", { color: e.target.value })} />
              </div>
              <UploadButton label="Logo equipo 2" onLoad={(url) => update("away", { logo: url })} />
            </div>

            <div className="recordTools">
              <button className={recording ? "stopRecordBtn" : "recordBtn"} onClick={recording ? stopRecording : startRecording}>
                {recording ? "Detener y descargar grabación" : "Grabar pantalla con overlay"}
              </button>
              <small>Al grabar, elige la pestaña de BasketCam para capturar cámara + marcador.</small>
            </div>

            <div className="adTools">
              <UploadButton label="Anuncio full pantalla imagen/video" accept="image/*,video/*" onLoad={loadFullAd} />
              <button className="showAdBtn" disabled={!fullAd} onClick={() => setShowFullAd(true)}>Mostrar anuncio full</button>
            </div>

            <UploadButton label="Banner inferior" onLoad={(url) => setSponsors((p) => ({ ...p, banner: url }))} />
          </div>
        </aside>
      </section>
    </main>
  );
}
