# BasketCam Pro V7 RTMP

Esta versión incluye:
- PWA React visual
- grabación local
- anuncio full screen
- panel visual V5/V6
- servidor Node RTMP
- envío a YouTube vía FFmpeg

## Requisitos
1. Node.js instalado
2. FFmpeg instalado y disponible en PATH
3. Una cuenta YouTube con transmisiones en vivo habilitadas

## Ejecutar

### Terminal 1
```bash
npm install
npm run server
```

### Terminal 2
```bash
npm run dev
```

Abrir:
```bash
http://localhost:5173
```

## Transmitir a YouTube manual

1. Entra a YouTube Studio.
2. Crea una transmisión.
3. Copia la URL RTMP completa:
   - servidor RTMP + stream key
   - ejemplo: `rtmp://a.rtmp.youtube.com/live2/xxxx-xxxx-xxxx-xxxx`
4. En BasketCam pega esa URL en el campo `YOUTUBE RTMP / STREAM KEY`.
5. Presiona `Transmitir a YouTube`.
6. El navegador pedirá qué capturar: elige la pestaña de BasketCam.

## Nota
Este V7 es RTMP manual. El login automático con Google/YouTube API viene después.
